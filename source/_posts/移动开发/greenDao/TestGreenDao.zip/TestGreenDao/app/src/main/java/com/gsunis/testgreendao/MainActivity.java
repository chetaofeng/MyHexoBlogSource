package com.gsunis.testgreendao;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.add)
    Button add;
    @BindView(R.id.del)
    Button del;
    @BindView(R.id.update)
    Button update;
    @BindView(R.id.query)
    Button query;
    @BindView(R.id.queryAll)
    Button queryAll;

    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        mContext = this;
    }

    @OnClick({R.id.add, R.id.del, R.id.update, R.id.query, R.id.queryAll})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.add:
                Student student = new Student(null,"张三", 25,"memeo");
                StudentDaoOpe.insertData(mContext, student);
                break;
            case R.id.del:
                //Student student = new Student(1l, "haung" + 5, 25);
                /**
                 * 根据特定的对象删除
                 */
               // StudentDaoOpe.deleteData(mContext, student);
                /**
                 * 根据主键删除
                 */
                //StudentDaoOpe.deleteByKeyData(mContext, 2l);

               StudentDaoOpe.deleteAllData(mContext);
                break;
            case R.id.update:
                Student student2 = new Student( 2l,"haungxiaoguo", 16516,"abc");
                StudentDaoOpe.updateData(mContext, student2);
                break;
            case R.id.query:
                List<Student> students = StudentDaoOpe.queryForId(mContext, 2l);
                for (int i = 0; i < students.size(); i++) {
                    Log.i("Log", students.get(i).getName());
                }
                break;
            case R.id.queryAll:
                List<Student> students2 = StudentDaoOpe.queryAll(mContext);
                for (int i = 0; i < students2.size(); i++) {
                    Log.i("Log", students2.get(i).getName()+"=="+students2.get(i).getAge()+"==="+students2.get(i).getMemo());
                }
                break;
        }
    }
}
